# O N E S Technologies Corporate Website

## Goal
Build a polished six-page website for the Dubai technology company using the verified details from the supplied business card and company ID.

## Pages
- Home — company introduction, services overview, Dubai presence, enquiry action
- About — company profile and CEO Sreehari C L
- Services — web/software development, IT, SEO, cloud, and data-entry services
- Portfolio — professional capability showcase without invented clients or results
- Careers — company culture and a direct application contact
- Contact — phone, email, office address, mailing address, and enquiry form

## Design
Use the “Precision Engineering” direction: crisp corporate typography, charcoal and emerald accents, clean architectural imagery, compact geometry, and restrained motion. Keep the spaced “O N E S” identity from the supplied materials.

## Content and interactions
- Shared desktop/mobile navigation and footer
- Working phone, email, WhatsApp, and page links
- Responsive mobile menu
- Contact form that prepares an email enquiry without requiring backend setup
- Accurate company details only; no invented awards, clients, testimonials, dates, or metrics

## Technical details
- Implement all six pages as separate TanStack routes with unique search and social metadata
- Define reusable semantic design tokens and shared site components
- Generate and use cohesive Dubai/technology imagery as local project assets
- Verify the finished website on desktop and mobile, including navigation and contact actions
