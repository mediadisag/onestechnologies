# Website build
- [x] Build six-page professional company website
- [x] Verify desktop/mobile navigation and contact actions
