# Dubai Web Creations

dubai based web development companykk avasyamaya oru website undakkanm, nalla professional website ayirikkanam, this is the comapany address and owner details,, i need  5-6 pages website

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://emirates-web-spark.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/5079490d-350c-4236-9626-e22c2e96871c).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
