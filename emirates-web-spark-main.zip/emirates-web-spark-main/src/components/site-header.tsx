import { Link } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";

const links = [
  ["/", "Home"], ["/about", "About"], ["/services", "Services"],
  ["/portfolio", "Portfolio"], ["/careers", "Careers"], ["/contact", "Contact"],
] as const;

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  return <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur">
    <div className="mx-auto flex h-18 max-w-7xl items-center justify-between px-5 lg:px-8">
      <Link to="/" className="flex items-center gap-3" onClick={() => setOpen(false)}>
        <span className="grid size-9 place-items-center rounded-sm bg-primary text-sm font-bold text-primary-foreground">1</span>
        <span><strong className="block text-sm tracking-[0.32em]">O N E S</strong><span className="block text-[9px] tracking-[0.18em] text-muted-foreground">TECHNOLOGIES CO LLC</span></span>
      </Link>
      <nav className="hidden items-center gap-7 lg:flex" aria-label="Primary navigation">
        {links.map(([to,label]) => <Link key={to} to={to} activeOptions={{ exact: to === "/" }} className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground" activeProps={{className:"text-foreground"}}>{label}</Link>)}
        <Button asChild><Link to="/contact">Start a project</Link></Button>
      </nav>
      <Button variant="ghost" size="icon" className="lg:hidden" aria-label={open ? "Close menu" : "Open menu"} onClick={() => setOpen(!open)}>{open ? <X/> : <Menu/>}</Button>
    </div>
    {open && <nav className="border-t border-border bg-background px-5 py-5 lg:hidden" aria-label="Mobile navigation"><div className="mx-auto flex max-w-7xl flex-col gap-1">{links.map(([to,label]) => <Link key={to} to={to} onClick={() => setOpen(false)} className="rounded-sm px-3 py-3 text-sm font-medium hover:bg-secondary">{label}</Link>)}</div></nav>}
  </header>;
}