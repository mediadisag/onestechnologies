import { createFileRoute, Link } from "@tanstack/react-router"; import { ArrowRight, Cloud, Code2, Database, Search, Server, ShieldCheck } from "lucide-react"; import { Button } from "@/components/ui/button"; import { SiteLayout, CtaBand } from "@/components/site-layout"; import { Reveal } from "@/components/reveal"; import hero from "@/assets/dubai-hero.jpg"; import office from "@/assets/dubai-office.jpg";
export const Route=createFileRoute("/")({head:()=>({meta:[{title:"O N E S Technologies — Web & IT Services Dubai"},{name:"description",content:"Dubai technology company delivering web development, IT, SEO, cloud, software and data services."},{property:"og:title",content:"O N E S Technologies — Digital Solutions from Dubai"},{property:"og:description",content:"Reliable web, software, cloud and IT services for businesses in the UAE and beyond."},{property:"og:type",content:"website"},{name:"twitter:card",content:"summary_large_image"}]}),component:Home});
const services=[{icon:Code2,title:"Web Development",text:"Fast, responsive websites and web applications designed around your business."},{icon:Server,title:"IT Services",text:"Dependable technology support that keeps teams productive and systems secure."},{icon:Search,title:"SEO Services",text:"Technical and content-led search improvements built for sustainable visibility."},{icon:Cloud,title:"Cloud Services",text:"Cloud setup, migration and management with performance and continuity in mind."},{icon:Database,title:"Data Entry",text:"Accurate, structured data processing delivered with consistency and care."},{icon:ShieldCheck,title:"Software Solutions",text:"Purpose-built business software that simplifies operations and scales with you."}];
function Home(){return <SiteLayout>
  <section className="relative isolate min-h-[88vh] overflow-hidden bg-ink">
    <img src={hero} width={1920} height={1200} className="absolute inset-0 -z-30 h-full w-full object-cover cine-zoom" alt="Dubai skyline and modern business district"/>
    <div className="absolute inset-0 -z-20 bg-cine-overlay"/>
    <div className="absolute inset-0 -z-10 cine-vignette"/>
    <div className="pointer-events-none absolute inset-0 -z-10 cine-grain"/>
    <div className="mx-auto flex min-h-[88vh] max-w-7xl items-center px-5 py-28 lg:px-8">
      <div className="max-w-3xl text-hero-foreground">
        <p className="label cine-rise text-brand-light" style={{animationDelay:"0.15s"}}>Technology partner · Dubai, UAE</p>
        <div className="mt-5 h-px w-28 origin-left bg-brand cine-sweep"/>
        <h1 className="mt-7 text-5xl font-semibold leading-[1.02] tracking-tight sm:text-6xl lg:text-7xl">
          <span className="block cine-rise" style={{animationDelay:"0.35s"}}>Digital foundations</span>
          <span className="block cine-rise" style={{animationDelay:"0.55s"}}>for businesses ready</span>
          <span className="block cine-rise text-brand-light" style={{animationDelay:"0.75s"}}>to move forward.</span>
        </h1>
        <p className="mt-7 max-w-xl cine-rise text-lg leading-8 text-hero-muted" style={{animationDelay:"0.95s"}}>O N E S Technologies creates reliable websites, software, cloud systems and digital growth solutions from the heart of Dubai.</p>
        <div className="mt-9 flex flex-wrap gap-3 cine-rise" style={{animationDelay:"1.15s"}}>
          <Button size="lg" asChild><Link to="/contact">Start a project <ArrowRight/></Link></Button>
          <Button size="lg" variant="heroOutline" asChild><Link to="/services">Explore services</Link></Button>
        </div>
      </div>
    </div>
    <div className="absolute inset-x-0 bottom-0 z-10 border-t border-ink-border/60 bg-ink/45 backdrop-blur-sm">
      <div className="mx-auto grid max-w-7xl gap-px px-5 py-5 text-ink-foreground sm:grid-cols-3 lg:px-8">
        {[["Based in","Al Karama, Dubai"],["Focus","Web · Software · Cloud"],["Speak to us","+971 58 847 9366"]].map(([k,v])=><div key={k} className="cine-rise" style={{animationDelay:"1.35s"}}><p className="label text-ink-muted">{k}</p><p className="mt-1 text-sm font-medium">{v}</p></div>)}
      </div>
    </div>
  </section>
  <section className="border-b border-border bg-background py-24">
    <div className="mx-auto max-w-7xl px-5 lg:px-8">
      <Reveal><div className="max-w-2xl"><p className="label text-brand">What we do</p><h2 className="mt-4 text-3xl font-semibold tracking-tight md:text-5xl">Technology that solves real business problems.</h2></div></Reveal>
      <div className="mt-14 grid border-l border-t border-border sm:grid-cols-2 lg:grid-cols-3">{services.map(({icon:Icon,title,text},i)=><Reveal key={title} delay={i*90}><div className="group h-full border-b border-r border-border p-7 transition-colors duration-500 hover:bg-secondary lg:p-9"><div className="flex items-center"><Icon className="size-6 text-brand transition-transform duration-500 group-hover:-translate-y-1"/></div><h3 className="mt-10 text-xl font-semibold">{title}</h3><p className="mt-3 text-sm leading-6 text-muted-foreground">{text}</p></div></Reveal>)}</div>
    </div>
  </section>
  <section className="py-24">
    <div className="mx-auto grid max-w-7xl items-center gap-14 px-5 lg:grid-cols-2 lg:px-8">
      <Reveal><div className="cine-frame rounded-sm"><img src={office} loading="lazy" width={1200} height={1504} alt="Contemporary glass office architecture" className="cine-frame-media aspect-[4/5] w-full object-cover"/></div></Reveal>
      <Reveal delay={140}><div><p className="label text-brand">Local presence, global standard</p><h2 className="mt-5 text-4xl font-semibold tracking-tight">Built in Dubai for a connected world.</h2><p className="mt-6 text-base leading-7 text-muted-foreground">Led by CEO Sreehari C L, our team brings practical thinking and disciplined delivery to every engagement. We work closely with businesses to turn ideas into useful, maintainable digital products.</p><div className="mt-9 border-l-2 border-brand pl-5"><p className="font-semibold">Unique World Business Center</p><p className="mt-1 text-sm leading-6 text-muted-foreground">Corridor 1, Office 136, Al Karama<br/>Dubai, UAE · P.O. Box 87556</p></div><Button variant="linkArrow" asChild className="mt-7 px-0"><Link to="/about">Meet the company <ArrowRight/></Link></Button></div></Reveal>
    </div>
  </section>
  <CtaBand/>
</SiteLayout>}
